package com.primeirotrampodev.segundoexercicio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SegundoexercicioApplicationTests {

	@Test
	void contextLoads() {
	}

}
